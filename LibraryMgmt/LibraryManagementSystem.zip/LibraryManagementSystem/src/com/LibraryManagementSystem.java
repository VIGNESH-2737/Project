package com;

import java.util.ArrayList;
import java.util.Date;

import com.login.LoginView;

public class LibraryManagementSystem {
	public static void main(String[] args) {
		
		LoginView v = new LoginView();
		v.init();
	}
}
