/**
 * 
 */
/**
 * @author sysadmin
 *
 */
module LibraryManagementSystem {
	
}